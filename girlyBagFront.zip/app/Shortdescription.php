<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shortdescription extends Model
{
    //
}
