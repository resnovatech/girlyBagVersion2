<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RewardPoint extends Model
{
    //
}
