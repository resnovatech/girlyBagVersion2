 <!-- jQuery -->    
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.min.js"></script>

    <!-- sticky -->
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.sticky.js"></script>

    <!-- OWL CAROUSEL Slider -->    
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/owl.carousel.min.js"></script>

    <!-- Boostrap --> 
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/bootstrap.min.js"></script>

    <!-- Countdown --> 
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.countdown.min.js"></script>

    <!--jquery Bxslider  -->
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.bxslider.min.js"></script>
    
    <!-- actual --> 
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.actual.min.js"></script>

    <!-- jQuery UI -->
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery-ui.min.js"></script>
    
    <!-- Chosen jquery-->    
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/chosen.jquery.min.js"></script>
    
    <!-- parallax jquery--> 
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/jquery.parallax-1.1.3.js"></script>

    <!-- elevatezoom --> 
    <script type="text/javascript" src="j{{ asset('/') }}public/front/s/jquery.elevateZoom.min.js"></script>

    <!-- fancybox -->
    <script src="{{ asset('/') }}public/front/js/fancybox/source/jquery.fancybox.pack.js"></script>
    <script src="{{ asset('/') }}public/front/js/fancybox/source/helpers/jquery.fancybox-media.js"></script>
    <script src="{{ asset('/') }}public/front/js/fancybox/source/helpers/jquery.fancybox-thumbs.js"></script>

    <!-- arcticmodal -->
    <script src="{{ asset('/') }}public/front/js/arcticmodal/jquery.arcticmodal.js"></script>
    
    <!-- Main -->  
    <script type="text/javascript" src="{{ asset('/') }}public/front/js/main.js"></script>