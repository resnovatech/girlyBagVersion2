<?php $__env->startSection('title'); ?>
The GirlyBag

<?php $__env->stopSection(); ?>




<?php $__env->startSection('body'); ?>
<div class="page-content">
    <div class="holder breadcrumbs-wrap mt-0">
        <div class="container">
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li><span>My account</span></li>
            </ul>
        </div>
    </div>
    <div class="holder">
        <div class="container">
            <div class="row">
                <div class="col-md-4 aside aside--left">
                    <div class="list-group">
                        <?php echo $__env->make('customerSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="col-md-14 aside">
                    <h1 class="mb-3">Account Details</h1>
                    <div class="row vert-margin">
                        <div class="col-sm-9">
                            <div class="card">
                                <div class="card-body">
                                    <h3>Personal Info</h3>
                                    <p><b>First Name:</b> <?php echo e(Auth::user()->name); ?><br>
                                        <b>Last Name:</b> <?php echo e(Auth::user()->lname); ?><br>
                                        <b>E-mail:</b> <?php echo e(Auth::user()->email); ?><br>
                                        <b>Phone:</b> <?php echo e(Auth::user()->phone); ?></p>
                                        <b>Reward Point:</b> <?php echo e($total_reward_point*$product_quantity); ?></p>
                                    <div class="mt-2 clearfix">
                                        <a href="#" class="link-icn js-show-form" data-form="#updateDetails"><i class="icon-pencil"></i>Edit</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3 d-none" id="updateDetails">
                        <form action="<?php echo e(route('customer_information_edit')); ?>" method ="post">
                            <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <h3>Update Account Details</h3>
                            <div class="row mt-2">
                                <div class="col-sm-9">
                                    <label class="text-uppercase">First Name:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control--sm" placeholder="Jenny" name="name" value="<?php echo e(Auth::user()->name); ?>">
                                        <input type="hidden" class="form-control form-control--sm" placeholder="Jenny" name="id" value="<?php echo e(Auth::user()->id); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-9">
                                    <label class="text-uppercase">Last Name:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control--sm" placeholder="Raider" name="lname" value="<?php echo e(Auth::user()->lname); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-sm-9">
                                    <label class="text-uppercase">E-mail:</label>
                                    <div class="form-group">
                                        <input type="email" class="form-control form-control--sm" placeholder="jennyraider@hotmail.com" name="email" value="<?php echo e(Auth::user()->email); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-9">
                                    <label class="text-uppercase">Phone:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control--sm" placeholder="876-432-4323" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="reset" class="btn btn--alt js-close-form" data-form="#updateDetails">Cancel</button>
                                <button type="submit" class="btn ml-1">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.page-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nirrtjiu/thegirlybag.com/resources/views/home.blade.php ENDPATH**/ ?>