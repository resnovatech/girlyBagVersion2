<?php $__env->startSection('title'); ?>
The GirlyBag

<?php $__env->stopSection(); ?>




<?php $__env->startSection('body'); ?>

<div class="page-content">
    <div class="holder breadcrumbs-wrap mt-0">
        <div class="container">
            <ul class="breadcrumbs">
                <li><a href="index.html">Home</a></li>
                <li><span>My account</span></li>
            </ul>
        </div>
    </div>
    <div class="holder">
        <div class="container">
            <div class="row">
                <div class="col-md-4 aside aside--left">
                    <div class="list-group">
                        <?php echo $__env->make('customerSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="col-md-14 aside">
                    <h1 class="mb-3">Order History</h1>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-order-history">
                            <thead>
                            <tr>
                                <th scope="col"># </th>
                                <th scope="col">Order Number</th>
                                <th scope="col">Order Date </th>
                                <th scope="col">Status</th>
                                <th scope="col">Total Price</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><b><?php echo e($newOrder->pin); ?></b> <!--<a href="cart.html" class="ml-1">View Details</a>--></td>
                                <td><?php echo e($newOrder->date); ?></td>
                                <td>
                                    <?php if($newOrder->status == 0): ?>

                                   Pending
                                    <?php elseif($newOrder->status == 1): ?>
                                    Confirmed
                                    <?php else: ?>
Processing
                                    <?php endif; ?>
                                </td>
                                <td><span class="color">$<?php echo e($newOrder->order_total); ?></span></td>
                                <td><!--<a href="#" class="btn btn--grey btn--sm">REORDER</a>--></td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-2">
                        <!--<a href="#" class="btn btn--alt">Clear History</a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.page-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nirrtjiu/thegirlybag.com/resources/views/front/customer_history.blade.php ENDPATH**/ ?>