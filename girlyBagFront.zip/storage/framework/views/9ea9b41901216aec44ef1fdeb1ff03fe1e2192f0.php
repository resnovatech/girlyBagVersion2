<a href="<?php echo e(route('home')); ?>" class="list-group-item <?php echo e(Route::is('home') ? 'active' : ''); ?>">Account Details</a>
<a href="<?php echo e(route('customer_addresss')); ?>" class="list-group-item <?php echo e((request()->is('customer_addresss'))? 'active' : ''); ?>">My Addresses</a>
<!--<a href="account-wishlist.php" class="list-group-item ">My Wishlist</a>-->
<a href="<?php echo e(route('customer_history')); ?>" class="list-group-item <?php echo e(Route::is('customer_history') ? 'active' : ''); ?>">My Order History</a>

<a href="<?php echo e(route('period_information')); ?>" class="list-group-item <?php echo e(Route::is('period_information') ? 'active' : ''); ?>">Period Information</a>
<?php /**PATH /home/nirrtjiu/thegirlybag.com/resources/views/customerSidebar.blade.php ENDPATH**/ ?>