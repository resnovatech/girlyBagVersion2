<?php if($message = Session::get('success')): ?>

<div class="mt-3 alert alert-success alert-dismissible fade show" role="alert">
    <i class="uil uil-check me-2"></i>
    <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">

    </button>
</div>

<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<div class="mt-3 alert alert-danger alert-dismissible fade show" role="alert">
    <i class="uil uil-exclamation-octagon me-2"></i>
    <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">

    </button>
</div>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<div class="mt-3 alert alert-warning alert-dismissible fade show" role="alert">
    <i class="uil uil-check me-2"></i>
    <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">

    </button>
</div>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<div class="mt-3 alert alert-info alert-dismissible fade show" role="alert">
    <i class="uil uil-check me-2"></i>
    <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">

    </button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mt-3 alert alert-danger alert-dismissible fade show" role="alert">
    <i class="uil uil-exclamation-octagon me-2"></i>
Please Check The Below Error
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">

    </button>
</div>
<?php endif; ?>
<?php /**PATH E:\project_2023\htdocs\girlyBagFront\resources\views/flash_message.blade.php ENDPATH**/ ?>