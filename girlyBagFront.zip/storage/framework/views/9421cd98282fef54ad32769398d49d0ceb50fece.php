<?php $__env->startSection('title'); ?>
The GirlyBag

<?php $__env->stopSection(); ?>




<?php $__env->startSection('body'); ?>
<div class="page-content">
    <div class="holder breadcrumbs-wrap mt-0">
        <div class="container">
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li><span>My account</span></li>
            </ul>
        </div>
    </div>
    <div class="holder">
        <div class="container">
            <div class="row">
                <div class="col-md-4 aside aside--left">
                    <div class="list-group">
                        <?php echo $__env->make('customerSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <?php if(empty($new_add)): ?>

                <div class="col-md-14 aside">
                    <h1 class="mb-3">My Addresses</h1>
                    <div class="row">
                        <div class="col-sm-9">
                            <div class="card">

                                <div class="card-body">
                                    <h3>Address 1 (Default)</h3>
                                    <p>Not Available</p>

                                    <div class="mt-2 clearfix">
                                        <a href="#" class="link-icn js-show-form" data-form="#updateAddress"><i class="icon-plus-sign"></i>Add</a>
                                        <!--<a href="#" class="link-icn ml-1 float-right"><i class="icon-cross"></i>Delete</a>-->
                                    </div>

                                </div>

                            </div>
                        </div>
                        <!--<div class="col-sm-9 mt-2 mt-sm-0">
                            <div class="card">
                                <div class="card-body">
                                    <h3>Address 2</h3>
                                    <p>Yuto Murase 42 1
                                        <br> Motohakone Hakonemaci Ashigarashimo
                                        <br> Gun Kanagawa 250 05 JAPAN
                                    </p>
                                    <div class="mt-2 clearfix">
                                        <a href="#" class="link-icn js-show-form" data-form="#updateAddress"><i class="icon-pencil"></i>Edit</a>
                                        <a href="#" class="link-icn ml-1 float-right"><i class="icon-cross"></i>Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>

                    <div class="card mt-3 d-none" id="updateAddress">
                        <form action="<?php echo e(route('customer_addresss_store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <h3>Edit Address</h3>
                            <label class="text-uppercase">Country:</label>
                            <div class="form-group select-wrapper">
                                <select class="form-control" name="country">
                                    <option value="Bangladesh">Banglades</option>

                                </select>
                            </div>
                            <label class="text-uppercase">District:</label>
                            <div class="form-group select-wrapper">
                                <select class="form-control" name="dis">
                                    <option value="Dhaka">Dhaka</option>

                                </select>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label class="text-uppercase">Phone:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" value="">
                                        <input type="hidden" class="form-control" name="id" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <label class="text-uppercase">Address:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="address" value="">
                                    </div>
                                </div>
                            </div>

                            <div class="mt-2">
                                <button type="reset" class="btn btn--alt js-close-form" data-form="#updateAddress">Cancel</button>
                                <button type="submit" class="btn ml-1">Add Address</button>
                            </div>
                        </div>
                    </form>
                    </div>

                </div>

                <?php else: ?>
                <div class="col-md-14 aside">
                    <h1 class="mb-3">My Addresses</h1>
                    <div class="row">
                        <div class="col-sm-9">
                            <div class="card">

                                <div class="card-body">
                                    <h3>Address 1 (Default)</h3>
                                    <p><?php echo e($new_add->Fname); ?> <?php echo e($new_add->lname); ?>

                                        <br> <?php echo e($new_add->phone); ?>

                                        <br> <?php echo e($new_add->address); ?></p>
                                    <div class="mt-2 clearfix">
                                        <a href="#" class="link-icn js-show-form" data-form="#updateAddress"><i class="icon-pencil"></i>Edit</a>
                                        <!--<a href="#" class="link-icn ml-1 float-right"><i class="icon-cross"></i>Delete</a>-->
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!--<div class="col-sm-9 mt-2 mt-sm-0">
                            <div class="card">
                                <div class="card-body">
                                    <h3>Address 2</h3>
                                    <p>Yuto Murase 42 1
                                        <br> Motohakone Hakonemaci Ashigarashimo
                                        <br> Gun Kanagawa 250 05 JAPAN
                                    </p>
                                    <div class="mt-2 clearfix">
                                        <a href="#" class="link-icn js-show-form" data-form="#updateAddress"><i class="icon-pencil"></i>Edit</a>
                                        <a href="#" class="link-icn ml-1 float-right"><i class="icon-cross"></i>Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <div class="card mt-3 d-none" id="updateAddress">
                        <form action="<?php echo e(route('customer_addresss_edit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <h3>Edit Address</h3>
                            <label class="text-uppercase">Country:</label>
                            <div class="form-group select-wrapper">
                                <select class="form-control" name="country">
                                    <option value="Bangladesh">Banglades</option>

                                </select>
                            </div>
                            <label class="text-uppercase">District:</label>
                            <div class="form-group select-wrapper">
                                <select class="form-control" name="dis">
                                    <option value="Dhaka">Dhaka</option>

                                </select>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label class="text-uppercase">Phone:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" value="<?php echo e($new_add->phone); ?>">
                                        <input type="hidden" class="form-control" name="id" value="<?php echo e($new_add->id); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <label class="text-uppercase">Address:</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="address" value="<?php echo e($new_add->address); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="mt-2">
                                <button type="reset" class="btn btn--alt js-close-form" data-form="#updateAddress">Cancel</button>
                                <button type="submit" class="btn ml-1">Update Address</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.page-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_2023\htdocs\girlyBagFront\resources\views/front/customer_address.blade.php ENDPATH**/ ?>