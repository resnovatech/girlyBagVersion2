<?php $__env->startSection('title'); ?>
The GirlyBag

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>
<?php


use App\Http\Controllers\MainController;


?>



<?php $__env->startSection('body'); ?>
<div class="page-content">
    <div class="holder breadcrumbs-wrap mt-0">
        <div class="container">
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li><span>Checkout</span></li>
            </ul>
        </div>
    </div>
    <form action="<?php echo e(route('shipping.store')); ?>" method="post" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>

        <?php if(Auth::guest()): ?>

        <div class="holder">
            <div class="container">
                <h1 class="text-center">Checkout page</h1>
                <div class="row">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <h2>Shipping Address</h2>
                                <p><a href="<?php echo e(route('customer_dashoard.login')); ?>">Login</a> or <a
                                        href="<?php echo e(route('customer_dashoard.register')); ?>">Register</a> for
                                    faster payment.</p>
                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>First Name:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('fname')): ?>
                                            <input type="text" class="form-control form-control--sm" name="fname"
                                                id="fname" value="<?php echo e(Session::get('fname')); ?>" required>
                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="fname"
                                                id="fname" required>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Last Name:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('lname')): ?>
                                            <input type="text" class="form-control form-control--sm" name="lname"
                                                id="fname" value="<?php echo e(Session::get('lname')); ?>" required>
                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="lname"
                                                id="fname" required>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2"></div>
                                <label>Country:</label>
                                <div class="form-group select-wrapper">
                                    <?php if(Session::has('country')): ?>
                                    <select class="form-control form-control--sm" name="country" required>
                                        <option value="BanglaDesh"
                                            <?php echo e(Session::get('country') == 'BanglaDesh' ? 'selected':''); ?>>BanglaDesh
                                        </option>

                                    </select>

                                    <?php else: ?>
                                    <select class="form-control form-control--sm" name="country" required>
                                        <option value="BanglaDesh">BanglaDesh</option>

                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="row">
                                    <div class="col-sm-9">
                                        <label>Area:</label>
                                        <div class="form-group select-wrapper">
                                            <?php if(Session::has('area_name')): ?>

                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($address->area); ?>" <?php echo e($address->area == Session::get('area_name') ? 'selected':''); ?>><?php echo e($address->area); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php else: ?>
                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($address->area); ?>"><?php echo e($address->area); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Phone:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('phone')): ?>

                                            <input type="text" class="form-control form-control--sm" name="phone"
                                                value="<?php echo e(Session::get('phone')); ?>" required>

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="phone"
                                                required>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2"></div>
                                <label>Address 1:</label>
                                <div class="form-group">
                                    <?php if(Session::has('address')): ?>
                                    <input type="text" class="form-control form-control--sm" name="address"
                                        value="<?php echo e(Session::get('address')); ?>" required>
                                    <?php else: ?>
                                    <input type="text" class="form-control form-control--sm" name="address" required>
                                    <?php endif; ?>
                                </div>
                                <div class="mt-2"></div>
                                <label>Last Period Date:ss</label>
                                <div class="form-group">
                                    <?php if(Session::has('pdate')): ?>
                                    <input type="date" class="form-control form-control--sm" name="pdate"
                                        value="<?php echo e(Session::get('pdate')); ?>" required>
                                    <?php else: ?>
                                    <input type="date" class="form-control form-control--sm" name="pdate" required>
                                    <?php endif; ?>
                                </div>
                                <div class="clearfix">
                                    <input id="formcheckoutCheckbox1" name="cstatus" type="checkbox" value="1">
                                    <label for="formcheckoutCheckbox1">Save address to my account</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 mt-2 mt-md-0">
                        <!--<div class="card">
                                <div class="card-body">
                                    <h2>Devivery Methods</h2>
                                    <div class="clearfix">
                                        <input id="formcheckoutRadio1" value="" name="radio1" type="radio" class="radio"
                                               checked="checked">
                                        <label for="formcheckoutRadio1">Standard Delivery $2.99 (3-5 days)</label>
                                    </div>
                                    <div class="clearfix">
                                        <input id="formcheckoutRadio2" value="" name="radio1" type="radio" class="radio">
                                        <label for="formcheckoutRadio2">Express Delivery $10.99 (1-2 days)</label>
                                    </div>
                                </div>
                            </div>-->
                        <div class="mt-2"></div>
                        <div class="card">
                            <div class="card-body">
                                <h2>Payment Methods</h2>
                                <div class="clearfix">
                                    <input id="formcheckoutRadio4" value="Cash On Delivery" name="payment_type"
                                        type="radio" class="radio" checked="checked">
                                    <label for="formcheckoutRadio4">Cash On Delivery</label>
                                </div>
                            </div>
                        </div>
                        <div class="mt-2"></div>
                        <div class="card">
                            <div class="card-body">
                                <h3>Order Comment</h3>

                                <?php if(Session::has('order_comment')): ?>

                                <textarea class="form-control form-control--sm textarea--height-200"
                                    placeholder="Place your comment here"
                                    name="order_comment"><?php echo e(Session::get('order_comment')); ?></textarea>

                                <?php else: ?>
                                <textarea class="form-control form-control--sm textarea--height-200"
                                    placeholder="Place your comment here" name="order_comment"></textarea>

                                <?php endif; ?>

                                <div class="card-text-info mt-2">
                                    <p>*Savings include promotions, coupons, rueBUCKS, and shipping (if applicable).</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-3"></div>
                <h2 class="custom-color">Order Summary</h2>
                <div class="row">
                    <div class="col-md-12">
                        <div class="cart-table cart-table--sm pt-3 pt-md-0">
                            <div class="cart-table-prd cart-table-prd--head py-1 d-none d-md-flex">
                                <div class="cart-table-prd-image text-center">
                                    Image
                                </div>
                                <div class="cart-table-prd-content-wrap">
                                    <div class="cart-table-prd-info">Name</div>
                                    <div class="cart-table-prd-qty">Qty</div>
                                    <div class="cart-table-prd-price">Price</div>
                                </div>
                            </div>
                            <?php $__currentLoopData = $cartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="cart-table-prd">
                                <div class="cart-table-prd-image">
                                    <a href="<?php echo e(route('product_single_view',$item->attributes->product_slug)); ?>"
                                        class="prd-img"><img class="lazyload fade-up"
                                            src="data:<?php echo e(asset('/')); ?><?php echo e('public/upload/'.$item->attributes->image); ?>"
                                            data-src="<?php echo e(asset('/')); ?><?php echo e('public/upload/'.$item->attributes->image); ?>"
                                            alt=""></a>
                                </div>
                                <div class="cart-table-prd-content-wrap">
                                    <div class="cart-table-prd-info">
                                        <h2 class="cart-table-prd-name"><a
                                                href="<?php echo e(route('product_single_view',$item->attributes->product_slug)); ?>"><?php echo e($item->name); ?></a>
                                        </h2>
                                    </div>
                                    <div class="cart-table-prd-qty">
                                        <div class="qty qty-changer">
                                            <input type="text" class="qty-input disabled" value="<?php echo e($item->quantity); ?>"
                                                data-min="0" data-max="1000">
                                        </div>
                                    </div>
                                    <div class="cart-table-prd-price-total">
                                        ৳ <?php echo e(\Cart::get($item->id)->getPriceSum()); ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mt-2 mt-md-0">
                        <div class="card">
                            <div class="card-body">
                                <h3>Apply Promocode</h3>
                                <p>Got a promo code? Then you're a few randomly combined numbers & letters away from fab
                                    savings!</p>

                                <?php if(Session::has('final_price')): ?>

                                <button type="submit" class="btn" value="removecupon" name="cupon">Remove Cupon</button>
                                <?php else: ?>

                                <div class="form-inline mt-2">
                                    <input type="hidden" class="form-control form-control--sm"
                                        placeholder="Promotion/Discount Code" name="total_price"
                                        value="<?php echo e(\Cart::getTotal()); ?>">




                                    <input type="text" class="form-control form-control--sm"
                                        placeholder="Promotion/Discount Code" name="code">

                                    <button type="submit" class="btn" value="cupon" name="cupon">Apply</button>
                                </div>

                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="mt-2"></div>
                        <?php if(Session::has('final_price')): ?>



                        <div class="cart-total-sm">

                            <span>Total Amount</span>
                            <span class="card-total-price">৳ <?php echo e(\Cart::getTotal()); ?></span>
                        </div>

                        <div class="cart-total-sm">

                            <span>Discount Amount</span>
                            <span class="card-total-price">৳ <?php echo e(Session::get('final_price')); ?></span>
                        </div>
                        <div class="cart-total-sm">

                            <span>Final Amount</span>
                            <span class="card-total-price">৳
                                <?php echo e(\Cart::getTotal() -  Session::get('final_price')); ?></span>
                        </div>


                        <?php else: ?>
                        <div class="cart-total-sm">

                            <span>Subtotal</span>
                            <span class="card-total-price">৳ <?php echo e(\Cart::getTotal()); ?> </span>
                        </div>

                        <?php endif; ?>
                        <div class="clearfix mt-2">
                            <button type="submit" class="btn btn--lg w-100">Place Order</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php else: ?>

        <?php
            $stock=MainController::stock(Auth::user()->id);
            ?>


        <?php
            $stock1=MainController::stock1(Auth::user()->id);
            ?>



        <div class="holder">
            <div class="container">
                <h1 class="text-center">Checkout page</h1>
                <div class="row">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">

                                <!--empty data check -->
                                <h2>Shipping Address</h2>

                                <?php if($stock1 == 0): ?>

                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>First Name:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('fname')): ?>
                                            <input type="text" class="form-control form-control--sm" name="fname"
                                                id="fname" value="<?php echo e(Session::get('fname')); ?>">
                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="fname"
                                                id="fname" value="<?php echo e(Auth::user()->name); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Last Name:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('lname')): ?>
                                            <input type="text" class="form-control form-control--sm" name="lname"
                                                id="fname" value="<?php echo e(Session::get('lname')); ?>">
                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="lname"
                                                id="fname" value="<?php echo e(Auth::user()->lname); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>Country:</label>
                                        <div class="form-group select-wrapper">
                                            <?php if(Session::has('country')): ?>
                                            <select class="form-control form-control--sm" name="country">
                                                <option value="BanglaDesh"
                                                    <?php echo e(Session::get('country') == 'BanglaDesh' ? 'selected':''); ?>>
                                                    BanglaDesh
                                                </option>

                                            </select>

                                            <?php else: ?>
                                            <select class="form-control form-control--sm" name="country">
                                                <option value="BanglaDesh">BanglaDesh</option>

                                            </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Area:</label>
                                        <div class="form-group select-wrapper">
                                            <?php if(Session::has('area_name')): ?>

                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($address->area); ?>" <?php echo e($address->area == Session::get('area_name') ? 'selected':''); ?>><?php echo e($address->area); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php else: ?>
                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($address->area); ?>"><?php echo e($address->area); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                </div>
                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>Phone:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('phone')): ?>

                                            <input type="text" class="form-control form-control--sm" name="phone"
                                                value="<?php echo e(Session::get('phone')); ?>">

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="phone">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Last Period Date:</label>
                                        <div class="form-group">
                                            <?php if(Session::has('pdate')): ?>
                                            <input type="date" class="form-control form-control--sm" name="pdate"
                                                value="<?php echo e(Session::get('pdate')); ?>">
                                            <?php else: ?>
                                            <input type="date" class="form-control form-control--sm" name="pdate">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>long does a period last?</label>
                                        <div class="form-group">
                                            <?php if(Session::has('total_days')): ?>

                                            <input type="text" class="form-control form-control--sm" name="total_days"
                                                value="<?php echo e(Session::get('total_days')); ?>">

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="total_days">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>How long is your cycle?</label>
                                        <div class="form-group">
                                            <?php if(Session::has('cycle')): ?>

                                            <input type="text" class="form-control form-control--sm" name="cycle"
                                                value="<?php echo e(Session::get('cycle')); ?>">

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="cycle">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2"></div>
                                <label>Address 1:</label>
                                <div class="form-group">
                                    <?php if(Session::has('address')): ?>
                                    <input type="text" class="form-control form-control--sm" name="address"
                                        value="<?php echo e(Session::get('address')); ?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control form-control--sm" name="address">
                                    <?php endif; ?>
                                </div>
                                <div class="mt-2"></div>

                                <div class="clearfix">
                                    <input id="formcheckoutCheckbox1" name="cstatus" type="checkbox" value="1">
                                    <label for="formcheckoutCheckbox1">Save address to my account</label>
                                </div>
                                <?php else: ?>

                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>First Name:</label>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control--sm" name="fname"
                                                value="<?php echo e($stock->Fname); ?>">
                                            <input type="hidden" class="form-control form-control--sm" name="id"
                                                value="<?php echo e($stock->id); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Last Name:</label>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control--sm" name="lname"
                                                value="<?php echo e($stock->lname); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2"></div>
                                <label>Country:</label>
                                <div class="form-group select-wrapper">
                                    <select class="form-control form-control--sm" name="country">
                                        <option value="BanglaDesh">BanglaDesh</option>

                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-9">
                                        <label>Area:</label>
                                        <div class="form-group select-wrapper">
                                            <?php if(Session::has('area_name')): ?>

                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($address->area); ?>"
                                                    <?php echo e($address->area == Session::get('area_name') ? 'selected':''); ?>>
                                                    <?php echo e($address->area); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php else: ?>
                                            <select class="form-control form-control--sm" name="dis" id="areaId">
                                                <?php $__currentLoopData = $ship_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($address->area); ?>"><?php echo e($address->area); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>Phone:</label>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control--sm" name="phone"
                                                value="<?php echo e($stock->phone); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2"></div>
                                <label>Address 1:</label>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control--sm" name="address"
                                        value="<?php echo e($stock->address); ?>">
                                </div>
                                <div class="mt-2"></div>
                                <label>Last Period Date:</label>
                                <div class="form-group">
                                    <?php if(Session::has('pdate')): ?>
                                    <input type="text" class="form-control form-control--sm" name="pdate"
                                        value="<?php echo e(Session::get('pdate')); ?>" id="datetimepicker12" required>
                                    <?php else: ?>
                                    <input type="text" class="form-control form-control--sm" name="pdate"
                                        id="datetimepicker12" required>
                                    <?php endif; ?>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-sm-9">
                                        <label>long does a period last?</label>
                                        <div class="form-group">
                                            <?php if(Session::has('total_days')): ?>

                                            <input type="text" class="form-control form-control--sm" name="total_days"
                                                value="<?php echo e(Session::get('total_days')); ?>">

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="total_days">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-9">
                                        <label>How long is your cycle?</label>
                                        <div class="form-group">
                                            <?php if(Session::has('cycle')): ?>

                                            <input type="text" class="form-control form-control--sm" name="cycle"
                                                value="<?php echo e(Session::get('cycle')); ?>">

                                            <?php else: ?>
                                            <input type="text" class="form-control form-control--sm" name="cycle">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix">
                                    <input id="formcheckoutCheckbox1" name="cstatus" type="checkbox" value="1">
                                    <label for="formcheckoutCheckbox1">Save address to my account</label>
                                </div>
                                <?php endif; ?>
                                <!--empty data check -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 mt-2 mt-md-0">
                        <!--<div class="card">
                                <div class="card-body">
                                    <h2>Devivery Methods</h2>
                                    <div class="clearfix">
                                        <input id="formcheckoutRadio1" value="" name="radio1" type="radio" class="radio"
                                               checked="checked">
                                        <label for="formcheckoutRadio1">Standard Delivery $2.99 (3-5 days)</label>
                                    </div>
                                    <div class="clearfix">
                                        <input id="formcheckoutRadio2" value="" name="radio1" type="radio" class="radio">
                                        <label for="formcheckoutRadio2">Express Delivery $10.99 (1-2 days)</label>
                                    </div>
                                </div>
                            </div>-->
                        <div class="mt-2"></div>
                        <div class="card">
                            <div class="card-body">
                                <h2>Payment Methods</h2>
                                <div class="clearfix">
                                    <input id="formcheckoutRadio4" value="Cash On Delivery" name="payment_type"
                                        type="radio" class="radio" checked="checked">
                                    <label for="formcheckoutRadio4">Cash On Delivery</label>
                                </div>
                            </div>
                        </div>
                        <div class="mt-2"></div>
                        <div class="card">
                            <div class="card-body">
                                <h3>Order Comment</h3>


                                <?php if(Session::has('order_comment')): ?>

                                <textarea class="form-control form-control--sm textarea--height-200"
                                    placeholder="Place your comment here"
                                    name="order_comment"><?php echo e(Session::get('order_comment')); ?></textarea>

                                <?php else: ?>
                                <textarea class="form-control form-control--sm textarea--height-200"
                                    placeholder="Place your comment here" name="order_comment"></textarea>

                                <?php endif; ?>


                                <div class="card-text-info mt-2">
                                    <p>*Savings include promotions, coupons, rueBUCKS, and shipping (if applicable).</p>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
                <div class="mt-3"></div>
                <h2 class="custom-color">Order Summary</h2>
                <!--new cart condition -->
                <?php if(isset($cart_data)): ?>
                <?php if(Cookie::get('shopping_cart')): ?>
                <?php $total="0" ?>
                <!-- new cart condition -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="cart-table cart-table--sm pt-3 pt-md-0">
                            <div class="cart-table-prd cart-table-prd--head py-1 d-none d-md-flex">
                                <div class="cart-table-prd-image text-center">
                                    Image
                                </div>
                                <div class="cart-table-prd-content-wrap">
                                    <div class="cart-table-prd-info">Name</div>
                                    <div class="cart-table-prd-qty">Qty</div>
                                    <div class="cart-table-prd-price">Price</div>
                                </div>
                            </div>
                            <?php $__currentLoopData = $cart_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="cart-table-prd">
                                <div class="cart-table-prd-image">
                                    <a href="<?php echo e(route('product_single_view',$data['item_slug'])); ?>" class="prd-img"><img
                                            class="lazyload fade-up"
                                            src="data:<?php echo e(asset('/')); ?><?php echo e('public/upload/'.$data['item_image']); ?>"
                                            data-src="<?php echo e(asset('/')); ?><?php echo e('public/upload/'.$data['item_image']); ?>"
                                            alt=""></a>
                                </div>
                                <div class="cart-table-prd-content-wrap">
                                    <div class="cart-table-prd-info">
                                        <h2 class="cart-table-prd-name"><a
                                                href="<?php echo e(route('product_single_view',$data['item_slug'])); ?>"><?php echo e($data['item_name']); ?></a>
                                        </h2>
                                    </div>
                                    <div class="cart-table-prd-qty">
                                        <div class="qty qty-changer">
                                            <input type="text" class="qty-input disabled"
                                                value="<?php echo e($data['item_quantity']); ?>" data-min="0" data-max="1000">
                                        </div>
                                    </div>
                                    <div class="cart-table-prd-price-total">
                                        ৳ <?php echo e(number_format($data['item_quantity'] * $data['item_price'], 2)); ?>

                                    </div>
                                </div>
                            </div>
                            <?php $total = $total + ($data["item_quantity"] * $data["item_price"]) ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mt-2 mt-md-0">
                        <div class="card">
                            <div class="card-body">
                                <h3>Apply Promocode</h3>
                                <p>Got a promo code? Then you're a few randomly combined numbers & letters away from fab
                                    savings!</p>
                                <?php if(session('success')): ?>
                                <div class="alert alert-success alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger alert-dismissible>">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('final_price')): ?>

                                <button type="submit" class="btn" value="removecupon" name="cupon">Remove Cupon</button>
                                <?php else: ?>

                                <div class="form-inline mt-2">
                                    <input type="hidden" class="form-control form-control--sm"
                                        placeholder="Promotion/Discount Code" name="total_price"
                                        value="<?php echo e(number_format($total, 2)); ?>">




                                    <input type="text" class="form-control form-control--sm"
                                        placeholder="Promotion/Discount Code" name="code">

                                    <button type="submit" class="btn" value="cupon" name="cupon">Apply</button>
                                </div>

                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="mt-2"></div>
                        <?php if(Session::has('final_price')): ?>



                        <div class="cart-total-sm">

                            <span>Total Amount</span>
                            <span class="card-total-price">৳ <?php echo e(number_format($total, 2)); ?></span>
                        </div>

                        <div class="cart-total-sm">

                            <span>Discount Amount</span>
                            <span class="card-total-price">৳ <?php echo e(Session::get('final_price')); ?></span>
                        </div>
                        <div class="cart-total-sm">

                            <!--delivary charge code-->
                            <?php if(Session::has('area_name')): ?>
                            <span>Delivary Charge</span>
                            <span class="card-total-price">৳ <?php echo e(Session::get('ship_price')); ?> </span>
                            <span>Final Amount</span>
                            <span class="card-total-price">৳
                                <?php echo e(number_format($total, 2) -  Session::get('final_price') +  Session::get('ship_price')); ?></span>

                                  <?php

                                $put_data_on_session = number_format($total, 2) -  Session::get('final_price') + Session::get('ship_price');

                                Session::put('CUPONPRICEDATA',$put_data_on_session);


                                ?>


                            <?php else: ?>

                            <!--delivary charge code-->

                            <span>Final Amount</span>
                            <span class="card-total-price">৳
                                <?php echo e(number_format($total, 2) -  Session::get('final_price')); ?></span>

                                  <?php

                                $put_data_on_session = number_format($total, 2) -  Session::get('final_price');

                                Session::put('CUPONPRICEDATA',$put_data_on_session);


                                ?>

                                <?php endif; ?>
                        </div>


                        <?php else: ?>
                        <div class="cart-total-sm">

                            <?php if(Session::has('area_name')): ?>
                            <span>Delivary Charge</span>
                            <span class="card-total-price">৳ <?php echo e(Session::get('ship_price')); ?> </span>
                            <span>Subtotal</span>
                            <span class="card-total-price">৳ <?php echo e($total + Session::get('ship_price')); ?> </span>
                            <?php else: ?>

                            <span>Subtotal</span>
                            <span class="card-total-price">৳ <?php echo e($total); ?> </span>
                            <?php endif; ?>
                        </div>

                        <?php endif; ?>
                        <div class="clearfix mt-2">
                            <button type="submit" class="btn btn--lg w-100">Place Order</button>
                        </div>
                    </div>
                </div>
                <!--new card condition-->
<?php endif; ?>
<?php endif; ?>
                <!--new card condition-->
            </div>
        </div>

        <?php endif; ?>

</div>
</form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function () {
        //add customer
        $("#areaId").on('change', function () {
            var customerId = $(this).val();

            //alert(customerId);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "<?php echo e(route('area_select')); ?>",
                type: "POST",
                data: {
                    'customerId': customerId
                },
                //dataType:'json',
                success: function (data) {


                    if (data == 1) {
                        location.reload(true);
                    } else {
                        alert('Something Went wrong Please Try Again.');
                    }

                },
                error: function () {
                    alert("error ase");
                }
            });
            //endajax
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.page-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_2023\htdocs\girlyBagFront\resources\views/front/ship_address.blade.php ENDPATH**/ ?>